const mongoose = require("mongoose");

// TODO: Connect to MangoDB

mongoose.connect('mongodb://localhost:27017/Todos',{useUnifiedTopology: true});


// Check if connection is successfull
const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", function () {
  console.log("Connected successfully");
});

// TODO:  Define the Schema for the Tasks collection

const Tasks_MySchema = new mongoose.Schema({
  title:{
      type: String,
      require: true,
  },
  completed:{
      type:Boolean,
      default:false
  },
  priority:{
    type: Number,
    require:true
  },
  categories:[{
    type:String,
    require:true,
    }
  ],
  author:{
    first_name:{type:String, require:true},
    last_name:{type:String, require:true}
  },
  assigne:[{type: mongoose.Schema.Types.ObjectId, ref: "students"}]

})

//// STUDENT SCHEMAR
const Students_MySchema = new mongoose.Schema({
  name:{type:String, require:true},
  class:{type:String, require:true}
})

// Create the Model for the Tasks collection from Schema
const TaskModel = mongoose.model("tasks", Tasks_MySchema);

const StudentModel = mongoose.model("students", Students_MySchema)

module.exports.TaskModel = TaskModel;

module.exports.StudentModel = StudentModel;

