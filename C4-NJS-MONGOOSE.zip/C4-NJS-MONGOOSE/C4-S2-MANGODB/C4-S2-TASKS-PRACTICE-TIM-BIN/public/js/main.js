

const URL = "http://localhost:3000"

function addTask(e) {
  e.preventDefault();
  let task = taskTitle.value;
  let priority = taskPriority.value;
  let author_firstName = firstName.value
  let author_lastName = lastName.value
  let taskCategories=[]
  let authors = {first_name:author_firstName, last_name:author_lastName}
  categories.forEach(element => {
    if(element.checked){
      taskCategories.push(element.value)
    }
  });

  let studentId=[]
  if(task_Assigned.checked){
    axios.get("/students").then((result)=>{
      let datas = result.data
      datas.forEach(element => {
        studentId.push(element._id)
      });
    })
    // TODO: request the server to create new task
    if(task!='' && priority!='' && taskCategories.length!="" && authors.length!=""){
      axios.post(URL + "/tasks/post", {title:task, priority:priority, categories:taskCategories, author:authors, assigne:studentId})
      .then(()=>{displayTasks()})
    }else{false}
    console.log("id_studetn", studentId);
  }

          
}

function displayTasks() {
  // TODO: request tasks from server and update DOM
  if(todo.checked){
     // GET ALL DATAS THAT DIDN'T COMPLETED
    axios.get("/tasks" + "/notCompleted").then((result)=>{
       let tasks = result.data
       tasks = tasks.reverse()
       refreshDOM(tasks)
    })
  }else{
    // GET ALL DATAS THAT COMPLETED
    axios.get("/tasks").then((result)=>{
       let tasks = result.data
       tasks = tasks.reverse()
       
       refreshDOM(tasks)
    })
  }
  
}

// REFRESH DOM

function refreshDOM (tasks) {
  while (screenToDisplay.firstChild) {
    screenToDisplay.removeChild(screenToDisplay.lastChild);
  }
  tasks.forEach((task) => {
    let card = document.createElement("div");
    card.id = task._id;
    if (task.completed) {
      card.className = "card mt-2 p-2 text-success";
    } else {
      card.className = "card mt-2 p-2 text-danger";
    }
    let p = document.createElement("p");
    p.textContent = task.title;
    let a_delete = document.createElement("a");
    a_delete.href = "#";
    a_delete.className = "delete";
    a_delete.textContent = "Delete";
    let hr = document.createElement("hr");
    card.appendChild(p);
    if (task.priority) {
      let p_prio = document.createElement("span");
      p_prio.textContent = "Priority= " + task.priority;
      card.appendChild(p_prio);
    }
    card.appendChild(hr);
    card.appendChild(a_delete);
    if (!task.completed) {
      let a_update = document.createElement("a");
      a_update.href = "#";
      a_update.className = "update";
      a_update.textContent = "Completed";
      card.appendChild(a_update);
    }
    screenToDisplay.appendChild(card);
  })
}


function clickTask(e) {
  e.preventDefault();
  if (e.target.className === "delete") {
    let isExecuted = confirm("Are you sure to delete this task?");
    if (isExecuted) {
      // TODO: Request to the server to detele one task
      axios.delete(URL + "/tasks/delete" + "/" + e.target.parentElement.id)
      .then(()=>{displayTasks()})
      .catch((error)=>console.log("delete error", error))
    }
  } else if (e.target.className === "update") {
    // TODO: Request to the server to update one task as completed
    axios.put(URL + "/tasks/update" + "/" + e.target.parentElement.id, {completed: true, id:e.target.parentElement.id})
    .then(()=>{displayTasks()})
    .catch((error)=>{console.log("update error: ", error)})
    console.log(e.target.parentElement.id);
  }

}

let screenToDisplay = document.querySelector(".result");
let taskTitle = document.querySelector("#task");
let taskPriority = document.querySelector("#priority");
let btnAddTask = document.querySelector("#addTask");
let todo = document.querySelector("#todo");

let categories = document.getElementsByName("categories")
let firstName = document.getElementById("first-name");
let lastName = document.getElementById("last-name")

let task_Assigned = document.getElementById("assigne")

btnAddTask.addEventListener("click", addTask);
screenToDisplay.addEventListener("click", clickTask);
todo.addEventListener("change", displayTasks);

displayTasks();

