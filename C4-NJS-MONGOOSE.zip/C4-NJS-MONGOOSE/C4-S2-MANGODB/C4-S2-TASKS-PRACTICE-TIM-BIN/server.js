const express = require("express");
var cors = require("cors");
const app = express();

app.listen(3000, () => {
  console.log("App run on http://localhost:3000");
});

// import Task model
const MyModel = require("./models/task_model");

app.use(cors({origin:"*"})); // To allow any origin
app.use(express.json()); // To read json data in request body
// Define static route
app.use(express.static("public"));

// TODO: Define dynamic routes

// GET TASK ALL
app.get("/tasks",(req, res)=>{
  MyModel.TaskModel.find()
  .populate("assigne")
  .then((result)=>{res.send(result)})
  .catch((error)=>{res.send(error)})
});
// GET TASK NOT COMPLETED
app.get("/tasks/notCompleted",(req, res)=>{
  MyModel.TaskModel.find({completed:false})
  .populate("assigne")
  .then((result)=>{res.send(result)})
  .catch((error)=>{res.send(error)})
});

// GET STUDENTS TO ASIGN TASK

app.get("/students",(req, res)=>{
  MyModel.StudentModel.find()
  .then((result)=>{res.send(result)})
  .catch((error)=>{res.send(error)})
});


app.post("/tasks/post", (req, res) => {
  MyModel.TaskModel.create(req.body)
  .then((result)=>{
      res.send(result);
  })
  .catch((error)=>{
      console.log(error);
  })
});


// DELETE TASK

app.delete("/tasks/delete/:id", (req, res)=>{
  MyModel.TaskModel.deleteOne({_id:req.params.id})
  .then((result)=>{res.send(result);})
  .catch((error)=>{res.send(error);})
})

// UPDATE DATA

app.put('/tasks/update/:id', (req, res)=> {
  MyModel.TaskModel.updateOne({_id:req.body.id}, {completed:req.body.completed})
  .then((task)=> {res.send(task)})
  .catch((error)=>{res.send(error)})
})