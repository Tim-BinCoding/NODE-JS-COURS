
// CONNECT DATA

const exp = require("constants");

const mongoose = require("mongoose");

mongoose.connect('mongodb://localhost:27017/Todos',{useUnifiedTopology:true});

// CREATE SERVER
const express = require("express");

const app = express();

const cors = require("cors");

app.use(cors({origin:"*"}))

app.listen(3000);


// CHECK CAN CONNECT TO MONGOSSE OR NOT

const db = mongoose.connection;
db.on("error",console.error.bind(console,"connection error:"));
db.once("open",function(){
    console.log("Connected successfully");
})

// ============================ QUERY CONNECT TO SCHEMA IN MONGOOSE ============================== //

const MySchema = new mongoose.Schema({
    title:{
        type: String,
        require: true,
    },
    completed:{
        type:Boolean
    }
})

// CONNECT SCHEDMA FROM MONGOOSE

const taskModel = mongoose.model("tasks", MySchema);

//// METHOD GET //////

app.get("/test", (req, res)=>{

    taskModel.find({completed:true}) // REQUEST SPECIFIC DATA FROM MONGODB

    .then((result)=>{

        res.send(result);

    })
    .catch((error)=>{
        res.send(error);
    })
})



////// METHOD POST TO MONGOOSE //////

app.use(express.urlencoded());
app.use(express.json());

app.post("/test", (req, res) => {
    taskModel.create(req.body)
    .then((result)=>{
        res.send(result);
    })
    .catch((error)=>{
        console.log(error);
    })
})


///// METHOD DELETE FROM MONGOOSE /////

app.delete("/delete/:id", (req, res)=>{
    taskModel.deleteOne({_id:req.params.id})
    .then((result)=>{res.send(result);})
    .catch((error)=>{res.send(error);})
})