function afterRequest(response) {
  // console.log(response);
  let gender = response.data.gender;
  let message = nameToTest + " is a " + gender;
  document.getElementById("answerId").textContent = message;
}
const GENDER_URL_BASE = "https://api.genderize.io?name=";
let nameToTest = "chum";
axios.get(`${GENDER_URL_BASE}${nameToTest}`).then(afterRequest);

// fetch(`${GENDER_URL_BASE}${nameToTest}`)
// 	.then(response => response.json())
// 	.then(data => console.log(data))
// 	.catch(err => console.error(err));








