let text1 = document.querySelector("#textFieldId1");
text1.style.textTransform = "uppercase";

// textFieldId1.style.textTransform = "uppercase";

let text2 = document.querySelector('#textFieldId2');
text2.style.textTransform = "lowercase";

// textFieldId2.style.textTransform = "lowercase";