// 1- Get the list of books ( tips : use the querySelectorAll )
// TODO


// 2- Display the number of books on paragrah "books-number"
// TODO


// 3- Display the title of the books  on paragrah "books-titles"
// TODO
