const { response } = require("express");
const express = require("express");
const { request } = require("http");
const app = express();

const PORT = 3000;
app.listen(PORT, () => {
  console.log(" listening on port  ! " + PORT);
});

// TODO : for each kind of request, code the appropriate function to CATCH it and ANSWER it

//		GET <SERVER IP>: 3000/bobo/baba
// app.get("/bobo/baba", (request, response)=>{
//   response.send("Bobo and baba are happy")
// })

//		GET <SERVER IP>: 3000
// app.get("/", (request, response)=>{
//   response.send("Hello")
// })

let data = {
  "pnc": 25,
  "rady": "Javascript",
  "ronan": "nothing found "
}

//		GET <SERVER IP>: 3000/weather?address=pnc
app.get("/weather", (request, response)=>{
  let weather = request.query.addresss
  response.send("The weather "+ weather.toUpperCase()+ " is " + data[weather])
})

//		GET <SERVER IP>: 3000/teacher/skills?name=rady
app.get("/teacher/skills", (request, response)=>{
  let name = request.query.name
  response.send("The weather "+ name.charAt(0).toUpperCase()+ " is " +data[name])
})

//		GET <SERVER IP>: 3000/teacher/skills?name=ronan

app.get("/teacher/skills", (request, response)=>{
  let name = request.query.name
  response.send("The weather "+ name.charAt(0).toUpperCase()+ " is " +data[name])
})



