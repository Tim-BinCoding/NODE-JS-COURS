const { request } = require("express");
const express = require("express");
const app = express();

const PORT = 3000;
app.listen(PORT,()=>console.log("It's running!!!"));

const STUDENTS = [ "Phally", "Sinai", "Siny", "Channary"]


// 1- Serve the /public folder to serve the FRONT-END code
app.use(express.static("test"))
// app.use(express.static("public"))
// 2-  On GET /students/   : return the list of students
app.get("/students", (request, response)=>{
    response.json(STUDENTS);
    response.end()
    
});
