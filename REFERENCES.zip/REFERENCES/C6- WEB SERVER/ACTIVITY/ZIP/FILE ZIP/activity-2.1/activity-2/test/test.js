function myData(response){
    console.log(response.data)
}

const url = "http://192.168.1.110:3000/students"
axios.get(url)
    .then(myData)


let container = document.querySelector(".container");
