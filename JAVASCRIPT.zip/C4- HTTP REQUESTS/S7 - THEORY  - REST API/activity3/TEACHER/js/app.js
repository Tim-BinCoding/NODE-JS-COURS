function requestMovie(event) {
  event.preventDefault();

  // TODO 1 : define the full URL to request the movie information entered in the input
  let movieName = searchInput.value;
  let url =
    "https://pixabay.com/api/?key=14001068-da63091f2a2cb98e1d7cc1d82&q="+ movieName;

  // We call teh request the URL
  axios
      .get(url)
      .then(response =>{
        for(let items of response.data.hits){
          console.log(items)
          let post = document.createElement("div");
          post.classList.add("post");

          let post_img = document.createElement("div");
          post_img.classList.add("post-img");

          let img = document.createElement("img");
          
          img.src = items.largeImageURL;
          post_img.appendChild(img);
          post.appendChild(post_img);
          let post_content = document.createElement("div");
          post_content.className = "post-content";

          let h2 = document.createElement("h2");
          h2.className = "movieTitle";
          let p_year = document.createElement("p");
          p_year.id = "year";
          let p_genre = document.createElement("p");
          p_genre.id = "genre";

          let p_actors = document.createElement("p");
          p_actors.id = "actors";

          post_content.appendChild(h2);
          post_content.appendChild(p_year);
          post_content.appendChild(p_genre);
          post_content.appendChild(p_actors);

          post.appendChild(post_content);
          

          
          console.log(items)
          document.querySelector(".container").appendChild(post)
        }
      });
}

const poster = document.querySelector("#poster");
const titleH2 = document.querySelector("#movieTitle");
const yearP = document.querySelector("#year");
const genreP = document.querySelector("#genre");
const actorsP = document.querySelector("#actors");

const searchInput = document.querySelector("#searchInput");
const searchButton = document.querySelector("#searchButton");
searchButton.addEventListener("click", requestMovie);
