const express = require("express");
const app = express();
const PORT = 3000;
// const { readFileSync, writeFileSync } = require("fs");

app.listen(PORT, () => console.log("Server running..."));
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Can be RED YELLOW or  GREEN

let status = "GREEN";

app.post("/status", (request, response) => {
  status = request.body.status;
  //let newColor = writeFileSync("colors.json", JSON.stringify(colors));
  response.send(status);
});

app.get("/status", (request, response) => {
  // let colors = JSON.parse(readFileSync("colors.json"));
  response.send(status);
});
