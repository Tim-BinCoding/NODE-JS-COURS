const express = require("express");
const app = express();
const PORT = 3000;
app.listen(PORT, ()=>console.log("It's is running!!!"));

// Example of REQUEST using QUERRY PARAMETERS
// app.get("/book", (req, res) => {
//   let id = req.query.id;
//   res.send("this request uses QUERY to get: " + id);
// });

// Example of REQUEST using ROUTE PARAMETERS
app.get("/book/:id/:color", (req, res) => {
  let id = req.params.id;
  let color = req.params.color
  res.send("this request uses PARAMS to get: " + id + " color " +color );
});
