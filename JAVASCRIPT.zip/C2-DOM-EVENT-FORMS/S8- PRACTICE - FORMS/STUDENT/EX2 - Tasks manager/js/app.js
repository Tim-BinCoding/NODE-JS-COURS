function addTask(event) {
  // --------- TO HELP YOU --------------------------
  // 1- Prevent default to avoid to refresh the page
  // TODO
  // 2- Get the form inputs  information
  // TODO
  // 3- Check if task text, color, date are defined :
  //    If not defined, display a warnning        "You must fill all inputs"
  // TODO
  // 4 - If defined:
  // 4-1- Create a span for the taks name
  //    - class = "task-name"
  // TODO
  // 4-2- Create a span for the taks date
  //    - class = "task-date"
  // TODO
  // 4-3- Create a p containing the 2 spans
  // TODO
  // 4-4- the P background color is the selected color - the text is back
  // TODO
}

// MAIN ----------------------------------------------------
const btnAddTask = document.getElementById("addTaskButton");
btnAddTask.addEventListener("click", addTask);
