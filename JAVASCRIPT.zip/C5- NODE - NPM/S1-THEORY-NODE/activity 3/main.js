


// 1- Import the module ‘fs’   (file system) to read and write files


// 2 - Write  a file rady.txt  with the content : Him is the best front programmer

// 3 - Read the content of the file  rady.txt

// 4 - Add to this content ‘But Ronan is the funniest’ and write again our file


