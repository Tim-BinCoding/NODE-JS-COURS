
// REQUIRE EXPRESS

const express = require("express");

// APP EXPRESS

const app = express();

// CALL BACK FUNCTION TO CHECK APPLICATION WORK OR ERROR

app.listen(3000, (error)=>{
    if(error){
        console.log(error);
    }else{
        console.log("Server is running ...");
    }
})

// CALL BACKE FUNCTION MUST BE THERE ARE TWO PARAMETER "REQUEST" AND "RESPONSE"

app.get("/", (request, response)=>{
    response.send("Hello world!!")
})