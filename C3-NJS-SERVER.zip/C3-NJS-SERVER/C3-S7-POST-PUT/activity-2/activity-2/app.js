const express = require("express");
const { status } = require("express/lib/response");
const app = express();

const PORT = 3000;
app.listen(PORT, () => console.log("Server starting on port: " + PORT));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

students = [
  {
    id: 1,
    first_name: "Calypso",
    last_name: "Eddis",
    email: "ceddis0@discovery.com",
  },
  {
    id: 2,
    first_name: "Calli",
    last_name: "Kleinplac",
    email: "ckleinplac1@mlb.com",
  }
];

// GET welcome node js
app.get("/", (req, res) => {
  console.log("Request from client: GET /");
  res.send("WELCOME NODE JS"); // res.send => send a string

});

// Get all students
app.get("/students", (req, res) => {
  console.log("Request from client: GET /students");
  res.json(students); // res.json => send an object
});

// Get student by id
app.get("/student/:id", (req, res) => {
  // console.log("Request from client: GET /student/" + req.params.id);
  students.forEach(element => {
    if(req.params.id == element.id){
      res.send(element)
    }
  });
  res.json({});
});

// Add student to body

app.post("/student", (req, res) => {
  let student = req.body;
  let addStudent = students.push(student);
  if(addStudent){
    res.send(student + "new add")
  }else{res.send("false")}
  res.json({});
});

app.put("/student/:id", (req, res) => {
  console.log("Request from client: PUT /student/" + req.params.id + " with body: " + JSON.stringify(req.body));
  
  res.json({});
});

app.delete("/student/:id", (req, res) => {
  console.log("Request from client: DELETE /student/" + req.params.id);

  students.forEach(element => {
    if(req.params.id == element.id){
      students.splice(element.id, 1)
      res.send("Ok")
    }else{res.send("false")}
  });
  res.json({});
});
