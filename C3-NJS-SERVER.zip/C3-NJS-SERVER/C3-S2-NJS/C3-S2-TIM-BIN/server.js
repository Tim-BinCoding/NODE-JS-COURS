


// 1- 	Using the FS module, read the file ./studentDatabase.json 
//		to get the list of students hobbies and favorites thing

const STUDENT_FILE = "./studentDatabase.json"

const fs = require("fs")

let student_infor = []

// 2- 	Using the module EXPRESS, start to listen to request on PORT 5000
const express = require("express");
const { query } = require("express");

const app = express();

app.listen(5000, (error)=>{
    if(error){
        console.log(error);
    }else{
        console.log("Server is running on port 5000");
    }
})


// 3-	Now answer to the following request:

//			GET  /favoriteTeacher?firstName= <student first name> & lastName= <student last name>
//			Return the favorite teacher of the student

//			Example for : 				GET  /favoriteTeacher?firstName=Channary&lastName=Pha
//			you should return : 		rady
// 			because of the JSON file, Channary Pha favorite teacher is Rady

app.get("/favoriteTeacher", (request, response)=>{
    student_infor = getStudents()
    let firstname = request.query.firstName
    let lastname = request.query.lastName
    student_infor.forEach(element => {
        if(element.firstName == firstname && element.lastName == lastname){
            response.send(element.favoriteteacher)
        }
    });
})


// 4-	Now answer to the following request:

//			GET  /favoriteCountry?firstName= <student first name> & lastName= <student last name>
//			Return the favorite country of the student

app.get("/favoriteCountry", (request, response)=>{
    student_infor = getStudents()
    let firstname = request.query.firstName
    let lastname = request.query.lastName
    student_infor.forEach(element => {
        if(element.firstName == firstname && element.lastName == lastname){
            response.send(element.favoriteCountry)
        }
    });
})


// 5-	Now answer to the following request:

//			GET  /students?favoriteTeacher= <teacher name>
//			Return the  list of  students first name  who like this teacher

//			Example for : 		GET  /students?favoriteTeacher=clement
//			you should return :  ["Somphors", "Nimout", "Vouleak", "Som"]
//			Because those students like clement

app.get("/students", (request, response)=>{
    student_infor = getStudents()
    let studetns_teacher =[]
    let teacherName = request.query.favoriteTeacher
    student_infor.forEach(element => {
        if(element.favoriteteacher==teacherName){
            studetns_teacher.push(element.firstName)
        }
    });
    response.send(studetns_teacher)
})



function getStudents() {
    let getData = JSON.parse(fs.readFileSync(STUDENT_FILE));
    console.log(getData);
    return getData;
}
