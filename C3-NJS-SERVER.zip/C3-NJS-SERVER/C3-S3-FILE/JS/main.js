

axios.get("/users").then((result)=>{
    console.log(result.data);
})