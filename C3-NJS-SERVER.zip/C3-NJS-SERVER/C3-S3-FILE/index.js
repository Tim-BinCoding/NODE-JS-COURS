
const express = require("express");

const app = express();

let users = [
    {name: "HIM HEY", gender: "M", phone: "0973344343"},
    {name: "KIM HAN", gender: "M", phone: "0973344343"},
    {name: "DIM HUY", gender: "M", phone: "0973344343"},
    {name: "TIM TUM", gender: "M", phone: "0973344343"},
    {name: "HUM HOY", gender: "M", phone: "0973344343"},
]

app.listen(5500, (error)=>{
    if(error){
        console.log(error);
    }else{
        console.log("servier is running");
    }
})

//// FILE SEND 
app.use(express.static("public"))

app.get("/users", (req, res)=>{
    res.send(users);
})



