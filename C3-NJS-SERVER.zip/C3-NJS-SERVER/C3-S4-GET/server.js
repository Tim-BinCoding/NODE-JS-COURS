


const express = require("express");
const res = require("express/lib/response");
const app = express();
const PORT = 3000;
//Start server
app.listen(PORT,()=>{
    console.log("localhost running on port: ", PORT);
});

//+++++++++++++++TODO+++++++++++++++++++++++

// Example of REQUEST using QUERRY PARAMETERS
// localhost:3000/book?id=100
app.get("/book", (req, res) => {
    console.log(res.send(req.query.id));
});

// Example of REQUEST using ROUTE PARAMETERS
// localhost:3000/book/200

app.get("/book/:id", (req, res) => {
    let id = req.params.id
    console.log(res.send(id));
});


