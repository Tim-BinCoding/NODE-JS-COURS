
const express = require("express");
const app = express();
const PORT = 3000;
const fs = require("fs");
// We serve assets on /public

app.use(express.static("public"));

app.listen(PORT, () => {
  console.log("server is running");
});

app.get("/items", (req, res) => {
    console.log("OK");
    let items = JSON.parse(fs.readFileSync("data.json"));
    res.send(items);
});

