
const PORT = 6000;

const express = require("express")

const app = express();

app.listen(PORT, ()=>{console.log("server is runing on port: ", PORT);})

app.use(express.static("public"));

app.get("/", (req, res)=>{
    
})