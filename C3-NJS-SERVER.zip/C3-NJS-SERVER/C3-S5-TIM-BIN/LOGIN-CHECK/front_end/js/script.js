const IP = "localhost";
const PORT = 3000;
const GET_LOGIN_REQUEST = "http://" + IP + ":" + PORT + "/login";

function login(e) {
  e.preventDefault();
  // 1- TODO: Create the REQUEST
  let querry = GET_LOGIN_REQUEST + "?userName=" + userName.value + "&password=" + password.value;
  console.log(querry);;
  axios.get(querry).then((response) => {
    let isValid = response.data;
    let text = "not valid";
    let color = "red";
    //2- TODO: check to change color to green and text= "Login success!" if login success.
    if(isValid){
      text = "Login success!"
      color = "green"
    }
    message.textContent = text;
    message.style.color = color;
  });
}

// MAIN---------------------------------------------------------------------------------------------
const message = document.querySelector("#message");
const userName = document.querySelector("#userName");
const password = document.querySelector("#password");
const btn = document.querySelector("#btn");
btn.addEventListener("click", login);


