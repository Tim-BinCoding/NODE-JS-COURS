// list of users for login.
let users = [
  { name: "him", password: "00000" },
  { name: "ronan", password: "11111" },
  { name: "rady", password: "22222" },
  { name: "edouar", password: "33333" },
];

// TODO: Create a server.

const cors = require("cors")

const express = require("express");

let app = express();

app.use(cors({origen:"*"}));

const PORT = 3000;

app.listen(PORT, (err)=>{console.log("run server on port: ",PORT);})
// login request path
app.use("/login", (req, res) => {
  //TODO: 
  //1. try to get the username and password from the query of the request.
  let username = req.query.userName;
  let password_user = req.query.password;
  //2. Check user and password if valid return true otherwise return false. 
  let isValid = false
  users.forEach(element => {
    if(element.name == username && element.password == password_user){
      isValid = true
    }
  });
  res.send(isValid);
});
app.use(express.static("front_end"));
