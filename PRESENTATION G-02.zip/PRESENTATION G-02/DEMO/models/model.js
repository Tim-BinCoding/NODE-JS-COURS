


const mongoose = require("mongoose");

const DATABASE = "mongodb://localhost:27017/APP_QUIZ"

// TODO: connect to mongodb
mongoose.connect(DATABASE,{useUnifiedTopology: true});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", function () {
  console.log("Schemar Connected successfully");
});
// TODO: create schemar for connect to collection in mongoose
const QuestionSchemar = new mongoose.Schema({
  quizId:{type: mongoose.Schema.Types.ObjectId, ref:"quizses"},
  question:{type:String, require:true},
  isCorrect:[{type:String,require:true}],
  answers:[{type:String, require:true}],
  score:{type:Number, require:true}
})

const QuizSchemar = new mongoose.Schema({
  title:{type:String, require:true},
  userId:{type: mongoose.Schema.Types.ObjectId, ref: "users"},
}) 

const UserSchemar = new mongoose.Schema({
  first_name:{type:String, require:true},
  last_name:{type:String, require:true},
  email:{type:String, require:true},
  password:{type:String, require:true}
})


// TODO: create model for connect to schemar
const UserModel = mongoose.model("users", UserSchemar)

const QuizModel = mongoose.model("quizses", QuizSchemar);

const QuestionModel = mongoose.model("questions", QuestionSchemar)

//TODO: export models
module.exports.UserModel = UserModel;
module.exports.QuizModel = QuizModel;
module.exports.QuestionModel = QuestionModel;