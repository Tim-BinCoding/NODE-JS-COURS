
const express = require('express');

const router = express.Router();

const exportModel = require('../models/model')

// get question by id quiz
router.get("/:quizId", (req, res)=>{
    exportModel.QuestionModel.find({quizId: req.params.quizId})
    .populate("quizId")
    .then((result)=>{ console.log(result); res.send(result)})
})

// create one quiz question
router.post('/add', (req, res) => {
    exportModel.QuestionModel.create(req.body)
    .then((result)=>{console.log(res.send(result))})
    .catch((error) => {res.send(error)})
})

// delete one quiz question
router.delete('/delete/:id', (req, res) => {
    exportModel.QuestionModel.deleteOne({ _id: req.params.id })
    .then(() => {res.send("Question delete successfully")})
    .catch((error) => {res.send(error)})
})

// update one quiz question
router.put('/update/:id', (req, res) => {
    exportModel.QuestionModel.updateMany({_id : req.params.id}, req.body)
    .then(()=>{res.send("Question update successfully")})
    .catch((error)=> {res.send(error)})
})

// TODO: export router
module.exports = router;