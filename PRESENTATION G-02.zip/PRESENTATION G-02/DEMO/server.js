// TODO: requirement

const express = require('express')
const cors = require("cors")
const app = express()
app.use(express.urlencoded({ extended : true }))
app.use(express.json())

const PORT = 80

app.use(cors({origin:"*"})); // To allow any origin

app.listen(PORT, () => {
    console.log('http://localhost:' + PORT)
})

// TODO: require question router

const questionRouter = require('./routers/question_router')

app.use('/questions', questionRouter)

